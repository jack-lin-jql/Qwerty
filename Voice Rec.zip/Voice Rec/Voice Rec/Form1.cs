﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Net;
using System.IO;

namespace Voice_Rec
{
    

    public partial class Form1 : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            btnDisable.Enabled = true;
            BtnEnable.Enabled = false;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "delete email", "get email", "send to" });
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);

            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += recEngine_SpeechRecognized;
        }

        void recEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
           
            bool b = e.Result.Text.Contains("send to");
            bool c = e.Result.Text.Contains("delete email");
            bool d = e.Result.Text.Contains("get email");

            if (b)
            {

                var message = "sending email";
                MessageBox.Show(message);

            }
            else if (c)
            {

                MessageBox.Show("deleting email....");
            }
            else if (d)
            {

                MessageBox.Show("getting email....");
            }

            /*switch(e.Result.Text)
            {
               case "say hello":

                    MessageBox.Show("hello john");
                   break;

               case "print my name":
                   richTextBox1.Text += "\nJohn";
                   break;


            }*/
        }

        private void btnDisable_Click(object sender, EventArgs e)
        {

            recEngine.RecognizeAsyncStop();
            btnDisable.Enabled = false;
            BtnEnable.Enabled = true;
        }
    }

    /*void httprequest() {
        var request = new Request();
        var response = request.Execute("http://localhost:8000/");
  
        var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://url");
        httpWebRequest.ContentType = "application/json";
        httpWebRequest.Method = "POST";

        using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
        {
            string json = "{\"user\":\"test\"," +
                          "\"password\":\"bla\"}";

            streamWriter.Write(json);
            streamWriter.Flush();
            streamWriter.Close();
        }

        var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
        {
            var result = streamReader.ReadToEnd();
        }
    }*/
    



}



